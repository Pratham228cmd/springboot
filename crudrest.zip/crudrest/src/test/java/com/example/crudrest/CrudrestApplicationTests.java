package com.example.crudrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
